package kr.hs.emirim.iuki1.calendartest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by KJY on 2017-10-22.
 */

public class ProjectList extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.projectlist);
        Intent intent = getIntent();
        String[] result = intent.getStringArrayExtra("결과");
        ArrayList<String> final_result = new ArrayList<String>();
        for(int j=0; j<result.length/5; j++){
            for(int i=0; i<result.length; i+=5){
                if(result[i]!=null){
                    final_result.add(result[i+1]+"\n"+result[i+2]+" ~ "+result[i+3]+"\n"+result[i+4]);
                }
            }
        }

        TextView tv = (TextView)findViewById(R.id.tv_top);
        tv.setText("프로젝트 리스트");

        ArrayAdapter<String> adapter;
        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, final_result);
        ListView list = (ListView) findViewById(R.id.project_list);
        list.setAdapter(adapter);

    }
}

