package kr.hs.emirim.iuki1.calendartest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.ListView;
import android.widget.TextView;

/**
 * Created by KJY on 2017-10-22.
 */

public class ProjectList extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.projectlist);
        Intent intent = getIntent();
        String[] result = intent.getStringArrayExtra("결과");
        for(int j=0; j<result.length; j++){
            if(result[j]!=null){
                Log.v("결과 ["+j+"] : ", result[j]);
            }
        }

        TextView tv = (TextView)findViewById(R.id.tv_top);
        tv.setText("프로젝트 리스트");

        ListView list = (ListView) findViewById(R.id.project_list);


    }
}

