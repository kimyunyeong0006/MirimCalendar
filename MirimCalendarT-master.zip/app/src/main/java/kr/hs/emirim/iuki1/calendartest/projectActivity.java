package kr.hs.emirim.iuki1.calendartest;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class projectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);
        TextView tv = (TextView)findViewById(R.id.tv_top);
        tv.setText("프로젝트 리스트");
        Toast.makeText(projectActivity.this,"추가를 원한다면 오른쪽 상단의 \n   버튼을 클릭해주세요",Toast.LENGTH_LONG).show();


        final ProjectDBHelper projectDBHelper = new ProjectDBHelper(getApplicationContext(), "Project_DB.db", null, 1);
        Button mShowDialog = (Button) findViewById(R.id.btn);

        final Intent intent = new Intent(this, ProjectList.class);


        mShowDialog.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(projectActivity.this);
                final View mView = getLayoutInflater().inflate(R.layout.project_insert, null);
                final EditText mProjectName = (EditText) mView.findViewById(R.id.etProjectName);
                final EditText mProjectContext = (EditText) mView.findViewById(R.id.etProjectMemo);

                final DatePicker mdpStart = (DatePicker) mView.findViewById(R.id.dpstart);
                final DatePicker mdpDead = (DatePicker) mView.findViewById(R.id.dpdead);

                final Button mInsert = (Button) mView.findViewById(R.id.btn_insert);

                mInsert .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if(!mProjectName.getText().toString().isEmpty() && !mProjectContext.getText().toString().isEmpty()){
                            Toast.makeText(projectActivity.this,
                                    "저장 되었습니다!",
                                    Toast.LENGTH_SHORT).show();
                           // projectDBHelper.drop();
                            //ProjectDBHelper
                            String start = getDateFromDatePicker(mdpStart);
                            String dead = getDateFromDatePicker(mdpDead);

                            // TextView tv = (TextView) findViewById(R.id.tv);
                            // tv.setText(tv.getText()+""+mdpStart.getYear()+"/"+(mdpStart.getMonth()+1)+"/"+mdpStart.getDayOfMonth());
                            projectDBHelper.insert(mProjectName.getText().toString(), start, dead, mProjectContext.getText());
                            String [][] result = projectDBHelper.getResult();
                            String [] final_result = new String[(result.length)*(result[0].length)];
//                            Log.v("length : ", String.valueOf(result.length));
//                            Log.v("length : ", String.valueOf(result[0].length));
                            for(int i=0; i<result.length; i++){
                                for(int j=0; j<result[0].length; j++) {
                                    Log.v("결과 ["+i+"]["+j+"] : ", result[i][j]);
                                }
                            }
//                            TextView tv = (TextView)mView.findViewById(R.id.tv);
                            int index=0;
                            for(int i=0; i<result.length; i++){
                                for(int j=0; j<result[0].length; j++){
                                    final_result[index++] = result[i][j];

                                }
                            }

                            for(int i=0; i<final_result.length; i++){
                                Log.v("결과 ["+i+"] : ", final_result[i]);
                            }

//                            projectDBHelper.getReadableDatabase();
//                            projectDBHelper.close();
                            intent.putExtra("결과", final_result);
                            startActivity(intent);
                            // DB에 데이터 추가
                        }else{
                            Toast.makeText(projectActivity.this,
                                    "비워있는 칸을 모두 채워주세요!",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
            }
        });
    }

    private static String getDateFromDatePicker(DatePicker mdp) {
        int year = mdp.getYear();
        int month = mdp.getMonth()+1;
        int day = mdp.getDayOfMonth();
        String date = year + "/" + month +"/" + day;
        Log.v("getDateFrom : ",date);
        return date;
    }
 }
