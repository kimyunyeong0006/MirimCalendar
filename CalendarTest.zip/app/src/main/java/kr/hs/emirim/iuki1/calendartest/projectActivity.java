package kr.hs.emirim.iuki1.calendartest;

import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Date;

public class projectActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project);

        final DBHelper dbHelper = new DBHelper(getApplicationContext(), "Project_DB.db", null, 1);
        Button mShowDialog = (Button) findViewById(R.id.btn);
        final DatePicker mdpStart = (DatePicker) findViewById(R.id.dpstart);
        final DatePicker mdpDead = (DatePicker) findViewById(R.id.dpdead);

        Log.v("통과","projectActivity1");

        mShowDialog.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                AlertDialog.Builder mBuilder = new AlertDialog.Builder(projectActivity.this);
                View mView = getLayoutInflater().inflate(R.layout.project_insert, null);
                final EditText mProjectName = (EditText)mView.findViewById(R.id.etProjectName);
                final Button mInsert = (Button)mView.findViewById(R.id.btn_insert);

                mInsert .setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {



                        if(!mProjectName.getText().toString().isEmpty()){
                            Toast.makeText(projectActivity.this,
                                    "Insert successful",
                                    Toast.LENGTH_SHORT).show();
                            //DBHelper
                            int startyear = mdpStart.getYear();
                            int startmonth = mdpStart.getMonth();
                            int startday = mdpStart.getDayOfMonth();
                            final Date start = new Date(startyear, startmonth, startday);

                            int deadyear = mdpDead.getYear();
                            int deadmonth = mdpDead.getMonth();
                            int deadday = mdpDead.getDayOfMonth();
                            final Date dead = new Date(deadyear, deadmonth, deadday);

                            // DB에 데이터 추가
                        }else{
                            Toast.makeText(projectActivity.this,
                                    "입력해주세요",
                                    Toast.LENGTH_SHORT).show();
                        }
                    }
                });
                mBuilder.setView(mView);
                AlertDialog dialog = mBuilder.create();
                dialog.show();
            }
        });
    }
}
