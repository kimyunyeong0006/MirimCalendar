package kr.hs.emirim.iuki1.calendartest;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by 김윤영 on 2017-10-21.
 */

public class todaysActivity extends AppCompatActivity{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_todays);

        TextView tv = (TextView)findViewById(R.id.tv_top);
        tv.setText("오늘의 소감문");

        TextView date = (TextView)findViewById(R.id.date);
        date.setText("10월 "+"21일"); //날짜

        TextView schedule = (TextView)findViewById(R.id.Schedule);
        schedule.setText("ㅁ 특강"); //행사 명 ex)특강, 봉사,

        TextView a_Input = (TextView)findViewById(R.id.activitiesInput);
        a_Input.setText(""); //주제 입력했던 값 있다면

        TextView i_Input = (TextView)findViewById(R.id.impressionInput);
        i_Input.setText(""); //소감 입력했던 값 있다면


        Button btn_save = (Button)findViewById(R.id.save_content);
        btn_save.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                //DB 구현하세요 . . . .
                Toast.makeText(todaysActivity.this, "저장되었어요", Toast.LENGTH_SHORT).show();
            }
        });
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
      //  Button btn_back = (Button)findViewById(R.toolbar.getId().toolbar_back);
        btn_save.setOnClickListener(new Button.OnClickListener(){
            @Override
            public void onClick(View v) {
                //DB 구현하세요 . . . .
                Toast.makeText(todaysActivity.this, "저장되었어요", Toast.LENGTH_SHORT).show();
            }
        });


    }
}
